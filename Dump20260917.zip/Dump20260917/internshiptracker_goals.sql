-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: localhost    Database: internshiptracker
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `goals`
--

LOCK TABLES `goals` WRITE;
/*!40000 ALTER TABLE `goals` DISABLE KEYS */;
INSERT INTO `goals` VALUES (1,'January',20,18,5,3,'Improve application consistency'),(2,'February',20,20,6,4,'Focus on software roles'),(4,'April',25,25,8,6,'Improve resume quality'),(5,'May',30,27,10,7,'Target top companies'),(6,'June',30,28,10,8,'Focus on internships'),(7,'July',35,30,12,8,'Increase interview preparation'),(8,'August',35,32,12,9,'Target software roles'),(9,'September',30,25,10,6,'Improve technical skills'),(10,'October',30,29,10,7,'Apply consistently'),(11,'November',25,23,8,6,'Focus on product companies'),(12,'December',20,18,6,4,'Year end internship search'),(13,'Week 1',5,5,2,1,'Weekly application target'),(14,'Week 2',5,4,2,1,'Improve interview preparation'),(15,'Week 3',5,5,2,2,'Focus on Python roles'),(16,'Week 4',5,4,2,1,'Apply to startups'),(17,'Quarter 1',60,55,18,12,'Quarterly internship goal'),(18,'Quarter 2',75,70,25,18,'Increase interview success'),(19,'Quarter 3',90,82,30,20,'Target product companies'),(20,'Quarter 4',75,68,25,17,'Final internship target');
/*!40000 ALTER TABLE `goals` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-17 19:20:36
