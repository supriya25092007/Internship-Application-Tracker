-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: localhost    Database: internshiptracker
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `offers_comparison`
--

LOCK TABLES `offers_comparison` WRITE;
/*!40000 ALTER TABLE `offers_comparison` DISABLE KEYS */;
INSERT INTO `offers_comparison` VALUES (1,2,18000.00,'2026-07-01','Chennai','9 AM - 6 PM','Certificate, Training',8,'Undecided'),(2,5,16000.00,'2026-07-02','Bangalore','9 AM - 6 PM','Certificate, Meals',7,'Undecided'),(3,6,15000.00,'2026-07-03','Chennai','10 AM - 7 PM','Certificate',7,'Undecided'),(4,9,22000.00,'2026-07-04','Bangalore','9 AM - 6 PM','Meals, Transport',9,'Undecided'),(5,10,30000.00,'2026-07-05','Hyderabad','9 AM - 6 PM','Accommodation, Meals',10,'Accepted'),(6,12,28000.00,'2026-07-06','Bangalore','10 AM - 7 PM','Meals, Training',9,'Undecided'),(7,14,20000.00,'2026-07-07','Chennai','9 AM - 6 PM','Certificate',8,'Undecided'),(8,16,25000.00,'2026-07-08','Pune','9 AM - 6 PM','Meals, Transport',9,'Undecided'),(9,17,24000.00,'2026-07-09','Bangalore','10 AM - 7 PM','Training, Certificate',8,'Undecided'),(10,19,17000.00,'2026-07-10','Mumbai','9 AM - 6 PM','Certificate',7,'Undecided'),(11,1,15000.00,'2026-07-11','Chennai','9 AM - 6 PM','Training',7,'Undecided'),(12,3,12000.00,'2026-07-12','Chennai','10 AM - 7 PM','Certificate',6,'Rejected'),(13,4,20000.00,'2026-07-13','Bangalore','9 AM - 6 PM','Meals',8,'Undecided'),(14,8,13000.00,'2026-07-14','Chennai','9 AM - 6 PM','Certificate',6,'Undecided'),(15,11,35000.00,'2026-07-15','Bangalore','9 AM - 6 PM','Accommodation, Meals',10,'Undecided'),(16,13,18000.00,'2026-07-16','Mumbai','9 AM - 6 PM','Training',7,'Undecided'),(17,15,15000.00,'2026-07-17','Pune','10 AM - 7 PM','Certificate',6,'Undecided'),(18,18,16000.00,'2026-07-18','Chennai','9 AM - 6 PM','Meals',7,'Undecided'),(19,20,19000.00,'2026-07-19','Hyderabad','9 AM - 6 PM','Training, Certificate',8,'Undecided'),(20,7,14000.00,'2026-07-20','Chennai','10 AM - 7 PM','Certificate',5,'Rejected');
/*!40000 ALTER TABLE `offers_comparison` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-17 19:20:37
