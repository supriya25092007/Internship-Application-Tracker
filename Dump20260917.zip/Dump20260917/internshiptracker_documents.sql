-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: localhost    Database: internshiptracker
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `documents`
--

LOCK TABLES `documents` WRITE;
/*!40000 ALTER TABLE `documents` DISABLE KEYS */;
INSERT INTO `documents` VALUES (1,1,'Resume','Resume_V1','/documents/resume_v1.pdf','2026-06-01'),(2,2,'Resume','Resume_V2','/documents/resume_v2.pdf','2026-06-02'),(3,3,'Cover Letter','Cover_V1','/documents/cover_v1.pdf','2026-06-03'),(4,4,'Resume','Resume_V3','/documents/resume_v3.pdf','2026-06-04'),(5,5,'Resume','Resume_V2','/documents/resume_v2.pdf','2026-06-05'),(6,6,'Cover Letter','Cover_V2','/documents/cover_v2.pdf','2026-06-06'),(7,7,'Resume','Resume_V2','/documents/resume_v2.pdf','2026-06-07'),(8,8,'Resume','Resume_V1','/documents/resume_v1.pdf','2026-06-08'),(9,9,'Resume','Resume_V3','/documents/resume_v3.pdf','2026-06-09'),(10,10,'Resume','Resume_V4','/documents/resume_v4.pdf','2026-06-10'),(11,11,'Cover Letter','Cover_V3','/documents/cover_v3.pdf','2026-06-11'),(12,12,'Resume','Resume_V3','/documents/resume_v3.pdf','2026-06-12'),(14,14,'Cover Letter','Cover_V4','/documents/cover_v4.pdf','2026-06-14'),(15,15,'Resume','Resume_V2','/documents/resume_v2.pdf','2026-06-15'),(16,16,'Resume','Resume_V4','/documents/resume_v4.pdf','2026-06-16'),(17,17,'Resume','Cover_V5','/documents/cover_v5.pdf','2026-06-17'),(18,18,'Resume','Resume_V2','/documents/resume_v2.pdf','2026-06-18'),(19,19,'Resume','Resume_V3','/documents/resume_v3.pdf','2026-06-19'),(20,20,'Resume','Resume_V4','/documents/resume_v4.pdf','2026-06-20');
/*!40000 ALTER TABLE `documents` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-17 19:20:37
