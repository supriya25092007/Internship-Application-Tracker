-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: localhost    Database: internshiptracker
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `status_history`
--

LOCK TABLES `status_history` WRITE;
/*!40000 ALTER TABLE `status_history` DISABLE KEYS */;
INSERT INTO `status_history` VALUES (1,1,'Not Applied','Applied','2026-06-01'),(2,2,'Applied','Shortlisted','2026-06-04'),(3,3,'Applied','Interview','2026-06-05'),(4,4,'Not Applied','Applied','2026-06-04'),(5,5,'Applied','Shortlisted','2026-06-07'),(6,6,'Applied','Interview','2026-06-08'),(7,7,'Applied','Rejected','2026-06-10'),(8,8,'Not Applied','Applied','2026-06-08'),(9,9,'Applied','Shortlisted','2026-06-12'),(10,10,'Applied','Interview','2026-06-13'),(11,11,'Not Applied','Applied','2026-06-11'),(12,12,'Applied','Shortlisted','2026-06-15'),(13,13,'Not Applied','Applied','2026-06-13'),(14,14,'Applied','Interview','2026-06-17'),(15,15,'Not Applied','Applied','2026-06-25'),(16,16,'Applied','Shortlisted','2026-06-18'),(17,17,'Applied','Interview','2026-06-19'),(18,18,'Not Applied','Applied','2026-06-18'),(19,19,'Applied','Shortlisted','2026-06-21'),(20,20,'Not Applied','Applied','2026-06-20');
/*!40000 ALTER TABLE `status_history` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-17 19:20:36
