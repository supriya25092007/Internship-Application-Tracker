-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: localhost    Database: internshiptracker
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `company_research`
--

LOCK TABLES `company_research` WRITE;
/*!40000 ALTER TABLE `company_research` DISABLE KEYS */;
INSERT INTO `company_research` VALUES (1,1,3.8,'Medium','Python, SQL, HR questions','Team oriented work culture','Glassdoor'),(2,2,3.9,'Medium','Java, OOP, SQL','Learning focused environment','Glassdoor'),(3,3,3.7,'Medium','JavaScript, Python, HR','Collaborative environment','Glassdoor'),(4,4,4.0,'Hard','DSA, SQL, case studies','Professional consulting culture','Glassdoor'),(5,5,3.8,'Medium','Java, SQL, OOP','Good training programs','Glassdoor'),(6,6,4.2,'Hard','Programming, logical reasoning','Product based culture','Glassdoor'),(7,7,4.1,'Medium','React, JavaScript, APIs','Startup style culture','Glassdoor'),(8,8,3.7,'Medium','Python, Java, SQL','Large team environment','Glassdoor'),(9,9,4.0,'Hard','Cloud, Java, system design','Technology focused culture','Glassdoor'),(10,10,4.3,'Hard','DSA, system design, coding','Innovation focused culture','Glassdoor'),(11,11,4.4,'Hard','Algorithms, ML, system design','Innovation and research culture','Glassdoor'),(12,12,4.1,'Hard','DSA, AWS, system design','Fast paced work environment','Glassdoor'),(13,13,4.0,'Medium','SQL, Excel, case studies','Professional environment','Glassdoor'),(14,14,3.8,'Medium','Cloud, Java, SQL','Training oriented culture','Glassdoor'),(15,15,3.6,'Medium','Java, Python, SQL','Team based environment','Glassdoor'),(16,16,4.0,'Hard','Python, SQL, data structures','Technology focused culture','Glassdoor'),(17,17,4.2,'Hard','Backend, APIs, system design','Startup environment','Glassdoor'),(18,18,4.0,'Medium','Flutter, Java, APIs','Fast paced startup culture','Glassdoor'),(19,19,3.9,'Medium','React, JavaScript, SQL','E-commerce work culture','Glassdoor'),(20,20,4.0,'Medium','Python, Java, SQL','Engineering focused culture','Glassdoor'),(21,23,4.9,'Medium','Cloud,Python,SQL','Engineering focused culture','Glassdoor');
/*!40000 ALTER TABLE `company_research` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-17 19:20:37
