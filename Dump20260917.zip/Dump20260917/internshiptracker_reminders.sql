-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: localhost    Database: internshiptracker
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `reminders`
--

LOCK TABLES `reminders` WRITE;
/*!40000 ALTER TABLE `reminders` DISABLE KEYS */;
INSERT INTO `reminders` VALUES (1,1,'Follow-up','2026-06-21','Follow up with TCS recruiter',0),(2,2,'Interview','2026-06-22','Prepare for Infosys interview',1),(3,3,'Interview','2026-06-23','Attend Wipro technical interview',1),(4,4,'Follow-up','2026-06-24','Check application status',0),(5,5,'Interview','2026-06-25','Prepare for Cognizant HR round',1),(6,6,'Interview','2026-06-26','Prepare full stack interview',0),(7,7,'Follow-up','2026-06-27','Review rejected application',1),(8,8,'Follow-up','2026-06-28','Contact HCL recruiter',0),(9,9,'Interview','2026-06-29','Prepare AWS interview questions',0),(10,10,'Interview','2026-06-30','Prepare Microsoft final round',1),(11,11,'Follow-up','2026-07-01','Check Google application',0),(12,12,'Interview','2026-07-02','Prepare Amazon interview',1),(13,13,'Follow-up','2026-07-03','Contact Deloitte recruiter',0),(14,14,'Interview','2026-07-04','Prepare Capgemini cloud round',0),(15,15,'Follow-up','2026-07-05','Check Tech Mahindra status',0),(16,16,'Interview','2026-07-06','Prepare PayPal assessment',0),(17,17,'Interview','2026-07-07','Prepare Razorpay system design',1),(18,18,'Follow-up','2026-07-08','Check Swiggy application',0),(19,19,'Interview','2026-07-09','Prepare Flipkart interview',1),(20,20,'Follow-up','2026-07-10','Contact Accolite recruiter',0);
/*!40000 ALTER TABLE `reminders` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-17 19:20:35
