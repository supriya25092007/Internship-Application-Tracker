-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: localhost    Database: internshiptracker
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `skills_required`
--

LOCK TABLES `skills_required` WRITE;
/*!40000 ALTER TABLE `skills_required` DISABLE KEYS */;
INSERT INTO `skills_required` VALUES (1,1,'Python','Advanced',4),(2,2,'Java','Intermediate',4),(3,3,'HTML/CSS','Intermediate',5),(4,4,'SQL','Advanced',4),(5,5,'Java','Advanced',3),(6,6,'JavaScript','Advanced',4),(7,7,'React','Intermediate',4),(8,8,'Python','Intermediate',5),(9,9,'AWS','Intermediate',3),(10,10,'C++','Advanced',4),(11,11,'Machine Learning','Advanced',3),(12,12,'Node.js','Advanced',4),(13,13,'Excel','Intermediate',5),(14,14,'Azure','Intermediate',3),(15,15,'Java','Intermediate',4),(16,16,'Python','Advanced',4),(18,18,'Flutter','Intermediate',3),(19,19,'React','Intermediate',5),(20,20,'Python','Intermediate',4),(21,31,'React','Advanced',5);
/*!40000 ALTER TABLE `skills_required` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-17 19:20:35
