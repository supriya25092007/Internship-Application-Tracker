-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: localhost    Database: internshiptracker
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `applications`
--

LOCK TABLES `applications` WRITE;
/*!40000 ALTER TABLE `applications` DISABLE KEYS */;
INSERT INTO `applications` VALUES (1,1,'Python Developer Intern','2026-06-01','Applied',15000.00,'Hybrid','Resume_V1','Python backend internship'),(2,2,'Software Developer Intern','2026-06-02','Shortlisted',18000.00,'Onsite','Resume_V2','Technical test completed'),(3,3,'Web Developer Intern','2026-06-03','Interview',12000.00,'Remote','Resume_V1','Interview scheduled'),(4,4,'Data Analyst Intern','2026-06-04','Applied',20000.00,'Hybrid','Resume_V3','Applied through portal'),(5,5,'Java Developer Intern','2026-06-05','Shortlisted',16000.00,'Onsite','Resume_V2','HR screening completed'),(6,6,'Full Stack Developer Intern','2026-06-06','Interview',15000.00,'Onsite','Resume_V3','Technical interview pending'),(7,7,'Frontend Developer Intern','2026-06-07','Rejected',14000.00,'Remote','Resume_V2','Application closed'),(8,8,'Python Developer Intern','2026-06-08','Applied',13000.00,'Hybrid','Resume_V1','Waiting for response'),(9,9,'Cloud Intern','2026-06-09','Shortlisted',22000.00,'Remote','Resume_V3','Cloud skills required'),(10,10,'Software Engineer Intern','2026-06-10','Interview',30000.00,'Hybrid','Resume_V4','Final round expected'),(11,11,'Machine Learning Intern','2026-06-11','Applied',35000.00,'Hybrid','Resume_V4','ML project included'),(12,12,'Backend Developer Intern','2026-06-12','Shortlisted',28000.00,'Onsite','Resume_V3','Coding test completed'),(13,13,'Business Analyst Intern','2026-06-13','Applied',18000.00,'Hybrid','Resume_V2','Case study preparation'),(14,14,'Cloud Engineer Intern','2026-06-14','Interview',20000.00,'Remote','Resume_V4','Technical round scheduled'),(15,15,'Software Developer Intern','2026-06-15','Applied',15000.00,'Onsite','Resume_V2','Waiting for assessment'),(16,16,'Data Science Intern','2026-06-16','Shortlisted',25000.00,'Hybrid','Resume_V4','Data science assessment'),(17,17,'Backend Engineer Intern','2026-06-17','Interview',24000.00,'Remote','Resume_V3','System design discussion'),(18,18,'Mobile App Developer Intern','2026-06-18','Applied',16000.00,'Hybrid','Resume_V2','Android development role'),(19,19,'React Developer Intern','2026-06-19','Shortlisted',17000.00,'Onsite','Resume_V3','React assessment completed'),(20,20,'Software Engineer Intern','2026-08-20','Applied',19000.00,'Remote','Resume_V4','Application submitted'),(30,21,'Software Engineer Intern','2026-09-15','Applied',20000.00,'On-site','Resume_V5','Applied'),(31,23,'Software Engineer Intern','2026-09-15','Applied',25000.00,'On-site','Resume_V5','Applied');
/*!40000 ALTER TABLE `applications` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-17 19:20:36
