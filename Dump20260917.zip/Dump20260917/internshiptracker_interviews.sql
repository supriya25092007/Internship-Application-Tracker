-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: localhost    Database: internshiptracker
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `interviews`
--

LOCK TABLES `interviews` WRITE;
/*!40000 ALTER TABLE `interviews` DISABLE KEYS */;
INSERT INTO `interviews` VALUES (1,2,1,'2026-06-10','Technical','Passed','Good programming knowledge'),(2,3,1,'2026-06-11','Technical','Pending','Python questions expected'),(3,5,1,'2026-06-12','HR','Passed','Good communication'),(4,6,1,'2026-06-13','Technical','Pending','Prepare full stack concepts'),(5,9,1,'2026-06-14','Technical','Passed','Strong cloud fundamentals'),(6,10,1,'2026-06-15','Technical','Passed','Excellent coding performance'),(7,10,2,'2026-06-17','Managerial','Pending','Leadership questions'),(8,12,1,'2026-06-16','Technical','Passed','Coding round cleared'),(9,14,1,'2026-06-18','Technical','Pending','Cloud concepts to revise'),(10,16,2,'2026-06-19','Technical','Passed','Good analytical skills'),(11,17,1,'2026-06-20','Technical','Pending','Prepare system design'),(12,19,1,'2026-06-21','Technical','Passed','Strong React knowledge'),(13,2,2,'2026-06-22','HR','Pending','HR discussion scheduled'),(14,5,2,'2026-06-23','Managerial','Pending','Managerial round'),(15,9,2,'2026-06-24','HR','Pending','HR discussion'),(16,12,2,'2026-06-25','HR','Passed','Good communication'),(17,14,2,'2026-06-26','HR','Pending','HR round pending'),(18,16,2,'2026-06-27','Managerial','Pending','Leadership discussion'),(19,17,2,'2026-06-28','Technical','Pending','Advanced backend concepts'),(20,19,2,'2026-06-29','HR','Pending','Final discussion'),(23,30,1,'2026-09-25','HR','Pending','pending'),(24,31,1,'2026-09-20','HR','Pending','pending');
/*!40000 ALTER TABLE `interviews` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-17 19:20:37
