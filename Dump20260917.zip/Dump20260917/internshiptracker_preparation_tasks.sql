-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: localhost    Database: internshiptracker
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `preparation_tasks`
--

LOCK TABLES `preparation_tasks` WRITE;
/*!40000 ALTER TABLE `preparation_tasks` DISABLE KEYS */;
INSERT INTO `preparation_tasks` VALUES (1,1,'Revise Python basics','2026-06-21',1),(2,2,'Practice Java coding','2026-06-22',1),(3,3,'Prepare HTML questions','2026-06-23',0),(4,4,'Practice SQL queries','2026-06-24',1),(5,5,'Revise Java OOP','2026-06-25',0),(6,6,'Build full stack project','2026-06-26',0),(7,7,'Revise React concepts','2026-06-27',1),(8,8,'Practice Python programs','2026-06-28',0),(9,9,'Study AWS services','2026-06-29',0),(10,10,'Practice coding problems','2026-06-30',1),(11,11,'Revise ML algorithms','2026-07-01',0),(12,12,'Practice Node.js','2026-07-02',1),(13,13,'Practice Excel analysis','2026-07-03',0),(14,14,'Study Azure concepts','2026-07-04',0),(15,15,'Revise Java concepts','2026-07-05',1),(16,16,'Practice Python ML','2026-07-06',0),(17,17,'Prepare Django project','2026-09-07',0),(18,18,'Practice Flutter','2026-07-08',1),(19,19,'Build React project','2026-07-09',1),(20,20,'Practice Python interview','2026-07-10',0);
/*!40000 ALTER TABLE `preparation_tasks` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-17 19:20:36
