-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: localhost    Database: internshiptracker
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `contacts`
--

LOCK TABLES `contacts` WRITE;
/*!40000 ALTER TABLE `contacts` DISABLE KEYS */;
INSERT INTO `contacts` VALUES (1,1,'Arun Kumar','HR Manager','linkedin.com/in/arunkumar','9876543210','arun@tcs.com','Recruiter'),(2,2,'Priya Sharma','Talent Specialist','linkedin.com/in/priyasharma','9876543211','priya@infosys.com','Recruiter'),(3,3,'Rahul Singh','HR Executive','linkedin.com/in/rahulsingh','9876543212','rahul@wipro.com','Recruiter'),(4,4,'Sneha Rao','Recruiter','linkedin.com/in/sneharao','9876543213','sneha@accenture.com','Recruiter'),(5,5,'Karthik Raj','HR Manager','linkedin.com/in/karthikraj','9876543214','karthik@cognizant.com','Recruiter'),(6,6,'Meena Joseph','Talent Partner','linkedin.com/in/meenajoseph','9876543215','meena@zoho.com','Alumni'),(7,7,'Vijay Anand','Recruiter','linkedin.com/in/vijayanand','9876543216','vijay@freshworks.com','Recruiter'),(8,8,'Divya Menon','HR Executive','linkedin.com/in/divyamenon','9876543217','divya@hcltech.com','Recruiter'),(9,9,'Sanjay Patel','Talent Manager','linkedin.com/in/sanjaypatel','9876543218','sanjay@ibm.com','Recruiter'),(10,10,'Neha Gupta','University Recruiter','linkedin.com/in/nehagupta','9876543219','neha@microsoft.com','Recruiter'),(11,11,'Aditya Verma','Technical Recruiter','linkedin.com/in/adityaverma','9876543220','aditya@google.com','Alumni'),(12,12,'Rohit Mehta','Recruiter','linkedin.com/in/rohitmehta','9876543221','rohit@amazon.com','Recruiter'),(13,13,'Anjali Nair','HR Manager','linkedin.com/in/anjalanair','9876543222','anjali@deloitte.com','Recruiter'),(14,14,'Vishal Kumar','Talent Specialist','linkedin.com/in/vishalkumar','9876543223','vishal@capgemini.com','Recruiter'),(15,15,'Harini Devi','HR Executive','linkedin.com/in/harinidevi','9876543224','harini@techmahindra.com','Alumni'),(16,16,'Naveen Rao','Recruiter','linkedin.com/in/naveenrao','9876543225','naveen@paypal.com','Recruiter'),(17,17,'Akash Shah','Talent Partner','linkedin.com/in/akashshah','9876543226','akash@razorpay.com','Recruiter'),(18,18,'Pooja Iyer','HR Executive','linkedin.com/in/poojaiyer','9876543227','pooja@swiggy.com','Recruiter'),(19,19,'Manoj Kumar','Recruiter','linkedin.com/in/manojkumar','9876543228','manoj@flipkart.com','Alumni'),(20,20,'Lakshmi Priya','HR Manager','linkedin.com/in/lakshmipriya','9876543229','lakshmi@accolite.com','Recruiter'),(21,23,'Lakshmi Priya','HR Manager','linkedin.com/in/lakshmipriya','9876543229','lakshmi@zoho.com','Recruiter');
/*!40000 ALTER TABLE `contacts` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-17 19:20:36
