-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: localhost    Database: internshiptracker
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `companies`
--

DROP TABLE IF EXISTS `companies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `companies` (
  `company_id` int NOT NULL AUTO_INCREMENT,
  `company_name` varchar(100) NOT NULL,
  `industry` varchar(50) DEFAULT NULL,
  `website` varchar(100) DEFAULT NULL,
  `hr_contact_email` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `companies`
--

LOCK TABLES `companies` WRITE;
/*!40000 ALTER TABLE `companies` DISABLE KEYS */;
INSERT INTO `companies` VALUES (1,'TCS','IT Services','https://www.tcs.com','hr@tcs.com'),(2,'Infosys','IT Services','https://www.infosys.com','hr@infosys.com'),(3,'Wipro','IT Services','https://www.wipro.com','hr@wipro.com'),(4,'Accenture','Consulting','https://www.accenture.com','hr@accenture.com'),(5,'Cognizant','IT Services','https://www.cognizant.com','hr@cognizant.com'),(6,'Zoho','Software','https://www.zoho.com','hr@zoho.com'),(7,'Freshworks','SaaS','https://www.freshworks.com','hr@freshworks.com'),(8,'HCLTech','IT Services','https://www.hcltech.com','hr@hcltech.com'),(9,'IBM','Technology','https://www.ibm.com','hr@ibm.com'),(10,'Microsoft','Technology','https://www.microsoft.com','hr@microsoft.com'),(11,'Google','Technology','https://www.google.com','hr@google.com'),(12,'Amazon','E-Commerce','https://www.amazon.com','hr@amazon.com'),(13,'Deloitte','Consulting','https://www.deloitte.com','hr@deloitte.com'),(14,'Capgemini','IT Services','https://www.capgemini.com','hr@capgemini.com'),(15,'Tech Mahindra','IT Services','https://www.techmahindra.com','hr@techmahindra.com'),(16,'PayPal','FinTech','https://www.paypal.com','hr@paypal.com'),(17,'Razorpay','FinTech','https://razorpay.com','hr@razorpay.com'),(18,'Swiggy','Food Technology','https://www.swiggy.com','hr@swiggy.com'),(19,'Flipkart','E-Commerce','https://www.flipkart.com','hr@flipkart.com'),(20,'Accolite','Software','https://www.accolite.com','hr@accolite.com'),(21,'Freshworks','Software','https://www.freshworks.com','hr@freshworks.com'),(23,'Zoho Corporation','Software','https://zoho.com','hr@zoho.com');
/*!40000 ALTER TABLE `companies` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-17 20:59:17
